#pragma once 
#include "ial.h"

int semProg();

